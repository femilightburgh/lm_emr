from sqlalchemy import String
from sqlalchemy.orm import Mapped, mapped_column
from sqlalchemy import Enum
from sqlalchemy.orm import relationship

from app.db.base_entity import BaseEntity
from app.modules.organization.enums import HospitalType


class Hospital(BaseEntity):
    __tablename__ = "hospitals"

    name: Mapped[str] = mapped_column(
        String(200),
        nullable=False,
    )

    code: Mapped[str] = mapped_column(
        String(20),
        nullable=False,
        unique=True,
        index=True,
    )

    hospital_type: Mapped[HospitalType] = mapped_column(
    Enum(HospitalType, name="hospital_type_enum"),
    nullable=False,
    )
    email: Mapped[str] = mapped_column(
        String(255),
        nullable=False,
    )

    phone: Mapped[str] = mapped_column(
        String(30),
        nullable=False,
    )

    website: Mapped[str | None] = mapped_column(
        String(255),
        nullable=True,
    )

    address: Mapped[str] = mapped_column(
        String(500),
        nullable=False,
    )

    city: Mapped[str] = mapped_column(
        String(100),
        nullable=False,
    )

    state: Mapped[str] = mapped_column(
        String(100),
        nullable=False,
    )

    country: Mapped[str] = mapped_column(
        String(100),
        nullable=False,
        default="Nigeria",
    )

    timezone: Mapped[str] = mapped_column(
        String(100),
        nullable=False,
        default="Africa/Lagos",
    )

    logo_url: Mapped[str | None] = mapped_column(
        String(500),
        nullable=True,
    )

    license_number: Mapped[str | None] = mapped_column(
        String(100),
        nullable=True,
    )

    user_accounts = relationship(
    "UserAccount",
    back_populates="hospital",
    cascade="all, delete-orphan",
    )

    roles = relationship(
        "Role",
        back_populates="hospital",
        cascade="all, delete-orphan",
    )