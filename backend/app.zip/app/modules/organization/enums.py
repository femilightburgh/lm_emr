from enum import Enum


class HospitalType(str, Enum):
    GENERAL = "General Hospital"
    SPECIALIST = "Specialist Hospital"
    TEACHING = "Teaching Hospital"
    PRIMARY = "Primary Health Centre"
    DIAGNOSTIC = "Diagnostic Centre"


class DepartmentCategory(str, Enum):
    CLINICAL = "Clinical"
    DIAGNOSTIC = "Diagnostic"
    ADMINISTRATIVE = "Administrative"
    SUPPORT = "Support"


class WardType(str, Enum):
    MEDICAL = "Medical"
    SURGICAL = "Surgical"
    PAEDIATRIC = "Paediatric"
    ICU = "ICU"
    NICU = "NICU"
    MATERNITY = "Maternity"
    ISOLATION = "Isolation"
    EMERGENCY = "Emergency"


class TheatreType(str, Enum):
    MAJOR = "Major"
    MINOR = "Minor"
    ENDOSCOPY = "Endoscopy"
    LABOUR = "Labour Ward Theatre"
    CARDIAC = "Cardiac"
    ORTHOPAEDIC = "Orthopaedic"
    