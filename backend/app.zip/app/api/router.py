"""
========================================================================

LIGHTBURGH EMR

Central API Router

========================================================================

Purpose
-------

This module aggregates all feature routers into a single API router.

Each business module registers its own routes here, allowing the
application entry point (main.py) to remain clean and scalable.

As new modules are introduced (Patients, Staff, Laboratory, Billing,
Pharmacy, etc.), their routers should be included here.

========================================================================
"""

from fastapi import APIRouter

from app.modules.identity.router import router as identity_router

api_router = APIRouter()

# ----------------------------------------------------------------------
# Identity Module
# ----------------------------------------------------------------------

api_router.include_router(identity_router)