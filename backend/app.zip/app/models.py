"""
LIGHTBURGH EMR

SQLAlchemy Model Registry

Import every model here so SQLAlchemy can resolve all
relationships before mapper configuration.
"""

# Organization
from app.modules.organization.models import Hospital

# Identity
from app.modules.identity.models import (
    UserAccount,
    Role,
    Permission,
    UserRole,
    RolePermission,
)

# Prevent "unused import" warnings
__all__ = [
    "Hospital",
    "UserAccount",
    "Role",
    "Permission",
    "UserRole",
    "RolePermission",
]